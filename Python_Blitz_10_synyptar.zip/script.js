// Әр карточканы басқанда жауабы ашылады немесе қайта жабылады.
const quizData = [
  {q:'a = [3, 6, 9]. a[1] мәні нешеге тең?', a:'6'},
  {q:'len([5, 1, 7, 2]) нәтижесі қандай?', a:'4'},
  {q:'range(2, 5) қандай сандарды береді?', a:'2, 3, 4'},
  {q:'return операторының қызметі қандай?', a:'Функция нәтижесін қайтарады'},
  {q:'Рекурсияда тоқтау шарты не үшін қажет?', a:'Рекурсивті шақыруларды тоқтату үшін'},
  {q:'a = [4, 8, 2]. a[-1] мәні қандай?', a:'2'},
  {q:'for x in [1, 4] циклі неше рет орындалады?', a:'2 рет'},
  {q:'Функцияның өзін қайта шақыруы қалай аталады?', a:'Рекурсия'},
  {q:'a.append(3) командасы не істейді?', a:'Тізімнің соңына 3 санын қосады'},
  {q:'Рекурсия мен циклдің ұқсастығы қандай?', a:'Екеуі де қайталанатын есептеулерді орындайды'}
];
const container = document.getElementById('questions');
const progress = document.getElementById('progress');
const buttons = [];
const revealed = new Set();
function updateProgress(){progress.textContent=`Ашылған жауаптар: ${revealed.size}/10`;}
function setAnswer(index, show){
 const button=buttons[index];
 const answer=button.querySelector('.answer');
 button.classList.toggle('revealed',show);
 button.setAttribute('aria-expanded',String(show));
 answer.hidden=!show;
 if(show)revealed.add(index);else revealed.delete(index);
 updateProgress();
}
quizData.forEach((item,index)=>{
 const button=document.createElement('button');
 button.type='button'; button.className='question';button.setAttribute('aria-expanded','false');
 const num=document.createElement('span');num.className='num';num.textContent=index+1;
 const content=document.createElement('span');content.className='content';
 const question=document.createElement('span');question.className='question-text';question.textContent=item.q;
 const answer=document.createElement('span');answer.className='answer';answer.textContent='Жауабы: '+item.a;answer.hidden=true;
 content.append(question,answer);button.append(num,content);
 button.addEventListener('click',()=>setAnswer(index,!revealed.has(index)));
 container.append(button);buttons.push(button);
});
document.getElementById('showAll').addEventListener('click',()=>buttons.forEach((_,i)=>setAnswer(i,true)));
document.getElementById('reset').addEventListener('click',()=>buttons.forEach((_,i)=>setAnswer(i,false)));
